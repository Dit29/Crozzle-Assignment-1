﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Position
    {
        public int row;
        public int column;

        public Position(int x, int y)
        {
            row = x;
            column = y;
        }
    }
}
